# Causal Bayesian Optimization Project

## Project Overview

This project combines AVICI's amortized causal discovery with PARENT_SCALE's guided causal optimization to create an end-to-end causal Bayesian optimization system. The key innovation is using amortized inference for both structure discovery and acquisition function modeling.

### Core Components
- **Surrogate Model**: ParentSetPredictionModel for amortized causal structure learning
- **Acquisition Model**: Target-aware intervention recommendation using GRPO
- **SCM Environment**: Immutable representations of structural causal models
- **Experience Buffer**: Trajectory storage with Sample dataclass

### Key Design Principles
- Immutable data structures for SCMs and samples
- Registry pattern for intervention handlers  
- Verifiable rewards without human feedback
- Multi-stage training pipeline
- Functional programming with pure functions
- Performance-conscious architecture (selective immutability)
- BIC scoring for robust model selection (prevents likelihood overfitting)
- Intervention diversity for effective causal discovery

## General Coding Standards

@~/.claude/CLAUDE.md

## AI Workflow
For complex tasks: Plan → Implement → Review → Delete plan before commit
- The plan should be formalized in a temporary .md file under root, after each significant check point this document should be updated (append only, no modification/deletion) to reflect the process made. It should act as a "source of truth" help coordination between different memebers involved in this task. Once we finish and validate the implementation we can delete the temporary doc, optionally creating a persistent, version in @docs

## Project Rules

### JAX Requirements
- No string operations in compiled functions
- No Python loops (use JAX vectorized operations)
- All models must be @jax.jit compatible
- Maintain [N, d, 3] data format

### Architecture
- Immutable data structures (SCMs, samples)
- Registry pattern for handlers
- Feature flags for optional capabilities
- Clean deprecation with warnings

## Imports
```python
import jax.numpy as jnp     # Never use 'np'
import numpy as onp         # I/O only
import jax.random as random
import pyrsistent as pyr
```

## Dependencies
- **Required**: jax, pyrsistent, haiku, optax
- **Testing**: hypothesis (property-based)
- **Forbidden**: pandas, sklearn, tensorflow, pytorch

## Types
```python
NodeId = str
SCM = pyr.PMap
Sample = pyr.PMap
```