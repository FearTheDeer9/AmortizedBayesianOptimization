This folder is taken from https://github.com/ssethz/multi-perturbation-ed for the SSG-finite baseline in our paper.
