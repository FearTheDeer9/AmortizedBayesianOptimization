color1 = "#EDB651"
color2 = "#95C965"
color3 = "#C9563E"
color4 = "#2A70C9"
color5 = "#800080"
color6 = "#F95B19"
color7 = "#B92AC9"
color8 = "#F95B19"

colors = [color1, color2, color3, color4, color5, color6, color7, color8]