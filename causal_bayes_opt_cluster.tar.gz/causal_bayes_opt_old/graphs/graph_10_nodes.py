import logging
from collections import OrderedDict
from itertools import chain
from typing import Any, Callable, Dict, List, Optional, OrderedDict, Tuple

import numpy as np

from graphs.graph import GraphStructure


class Graph10Nodes(GraphStructure):

    def __init__(self):
        pass

    def define_SEM(self):
        pass

    def get_all_do(self):
        pass

    def get_interventional_range(self):
        return super().get_interventional_range()
