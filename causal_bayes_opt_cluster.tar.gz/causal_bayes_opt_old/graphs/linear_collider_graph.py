import logging
import sys
from collections import OrderedDict
from itertools import chain
from typing import Dict, List, Optional, Tuple

import numpy as np
from emukit.core import ContinuousParameter, ParameterSpace
from GPy.kern import RBF
from GPy.models.gp_regression import GPRegression

from graphs.graph import GraphStructure

sys.path.append("..")


class LinearColliderGraph(GraphStructure):
    """
    ToyGraph structure X -> Z -> Y for fair comparison testing.
    
    This matches exactly the original ToyGraph structure used in PARENT_SCALE:
    - X: root variable (mean=0, noise=0.2)
    - Z: depends on X: Z = X + noise (noise=0.2)
    - Y: depends on Z: Y = Z + noise (noise=0.2)
    
    Target variable is Y (minimization) to match original ToyGraph.
    """

    def __init__(
        self,
        X: np.ndarray = None,
        Y: np.ndarray = None,
        Z: np.ndarray = None,
        noiseless: bool = False,
    ):
        logging.info("Initializing ToyGraph Structure: X -> Z -> Y")
        self.X = X
        self.Y = Y
        self.Z = Z
        self.noiseless = noiseless
        self._SEM = self.define_SEM()
        self._edges = [("X", "Z"), ("Z", "Y")]  # X -> Z -> Y (chain, like ToyGraph)
        self._nodes = set(chain(*self.edges))
        self._parents, self._children = self.build_relationships()
        self._variables = ["X", "Z", "Y"]
        self._G = self.make_graphical_model()
        self._target = "Y"  # Target for optimization (like ToyGraph)
        self._functions: Optional[Dict[str, GPRegression]] = None
        self._standardised = False

    def define_SEM(self) -> OrderedDict:
        """
        Define SEM functions matching ToyGraph exactly:
        - X: root variable (just noise)
        - Z: depends on X: Z = X + epsilon
        - Y: depends on Z: Y = Z + epsilon
        
        Note: noise scaling is handled in get_error_distribution()
        """
        def fx(epsilon, sample):
            """Root variable X = epsilon (noise will be scaled appropriately)"""
            return epsilon

        def fz(epsilon, sample):
            """Z depends on X: Z = X + epsilon"""
            x_val = sample.get("X", 0.0)
            return x_val + epsilon

        def fy(epsilon, sample):
            """Y depends on Z: Y = Z + epsilon"""
            z_val = sample.get("Z", 0.0)
            return z_val + epsilon

        # Create the SEM graph with topological order X -> Z -> Y
        graph = OrderedDict([("X", fx), ("Z", fz), ("Y", fy)])
        return graph

    def get_error_distribution(self, noiseless: bool = False) -> Dict[str, float]:
        """
        Get error distribution matching ToyGraph noise scales:
        - X: noise_scale = 0.2 (root variable)
        - Z: noise_scale = 0.2 (depends on X)
        - Y: noise_scale = 0.2 (depends on Z, target variable)
        """
        if noiseless:
            return {var: 0.0 for var in self.variables}
        
        # Match noise scales from ToyGraph (all 0.2 for consistency)
        return {
            "X": np.random.normal(0, 0.2),
            "Z": np.random.normal(0, 0.2), 
            "Y": np.random.normal(0, 0.2)
        }

    def set_data(self, X: np.ndarray, Y: np.ndarray, Z: np.ndarray):
        """Setting the data for the first time"""
        self.X = X
        self.Y = Y
        self.Z = Z

    def fit_all_models(self) -> None:
        """
        Fit GP models based on the original data.
        For chain structure X -> Z -> Y:
        - Z regressed on [X]
        - Y regressed on [Z]
        - X is root variable (no regression)
        """
        logging.info("Fitting Gaussian Processes for ToyGraph Chain Structure")
        assert self.X is not None and self.Y is not None and self.Z is not None

        # Regress Z on [X] - chain structure  
        features_Z = self.X.reshape(-1, 1)
        targets_Z = self.Z.reshape(-1, 1)
        
        kernel_Z = RBF(1, ARD=False, lengthscale=1.0, variance=1.0)
        gp_Z = GPRegression(X=features_Z, Y=targets_Z, kernel=kernel_Z, noise_var=0.1)
        gp_Z.optimize()

        # Regress Y on [Z] - chain structure
        features_Y = self.Z.reshape(-1, 1) 
        targets_Y = self.Y.reshape(-1, 1)
        
        kernel_Y = RBF(1, ARD=False, lengthscale=1.0, variance=1.0)
        gp_Y = GPRegression(X=features_Y, Y=targets_Y, kernel=kernel_Y, noise_var=0.1)
        gp_Y.optimize()

        # X is root variable - no regression needed
        self._functions = OrderedDict([("Z", gp_Z), ("Y", gp_Y), ("X", [])])

    def refit_models(self, observational_samples: dict) -> None:
        """
        Refit gaussian processes based on new observational samples
        """
        logging.info("Refitting Gaussian Processes with new data")
        X = np.asarray(observational_samples["X"]).reshape(-1, 1)
        Y = np.asarray(observational_samples["Y"]).reshape(-1, 1)
        Z = np.asarray(observational_samples["Z"]).reshape(-1, 1)

        # Refit Z on [X] for chain structure
        kernel_Z = RBF(1, ARD=False, lengthscale=1.0, variance=1.0)
        gp_Z = GPRegression(X=X, Y=Z, kernel=kernel_Z, noise_var=0.1)
        gp_Z.optimize()

        # Refit Y on [Z] for chain structure
        kernel_Y = RBF(1, ARD=False, lengthscale=1.0, variance=1.0)
        gp_Y = GPRegression(X=Z, Y=Y, kernel=kernel_Y, noise_var=0.1)
        gp_Y.optimize()

        # Update functions
        self._functions["Z"] = gp_Z
        self._functions["Y"] = gp_Y

    def get_interventional_range(self, D_O: dict = None) -> Dict[str, List[float]]:
        """
        Get intervention ranges for variables.
        
        If observational data is provided, derive ranges from data.
        Otherwise use default ranges.
        """
        if D_O is not None:
            # Data-derived ranges with 20% extension (matching our integration)
            ranges = {}
            for var in self.variables:
                if var in D_O:
                    data = D_O[var].flatten() if hasattr(D_O[var], 'flatten') else np.array(D_O[var])
                    data_min = float(np.min(data))
                    data_max = float(np.max(data))
                    range_extend = (data_max - data_min) * 0.2
                    ranges[var] = [data_min - range_extend, data_max + range_extend]
                else:
                    ranges[var] = [-2.0, 2.0]  # Default
            return ranges
        else:
            # Default ranges
            return {
                "X": [-2.0, 2.0],
                "Y": [-2.0, 2.0], 
                "Z": [-3.0, 3.0]  # Wider range for target variable
            }

    def get_sets(self) -> Tuple[List[str], List[str], List[str]]:
        """
        Get variable sets for CBO algorithm.
        
        Returns:
            Tuple of (all_variables, target_variables, manipulative_variables)
        """
        all_variables = self.variables.copy()
        target_variables = [self.target]
        manipulative_variables = [var for var in self.variables if var != self.target]
        
        return all_variables, target_variables, manipulative_variables

    def get_exploration_set(self) -> List[Tuple[str]]:
        """Override to match ToyGraph exploration set exactly: [("X",), ("Z",), ("X", "Z")]."""
        return [("X",), ("Z",), ("X", "Z")]