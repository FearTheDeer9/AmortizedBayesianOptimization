python3 large_graph_bash.py "Erdos15" "all" $1
# python3 large_graph_bash.py "Erdos15" "all" --nonlinear $1