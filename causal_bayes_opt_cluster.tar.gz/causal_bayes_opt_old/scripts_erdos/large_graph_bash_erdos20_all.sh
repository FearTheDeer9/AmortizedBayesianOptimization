python3 large_graph_bash.py "Erdos20" "all" $1
# python3 large_graph_bash.py "Erdos20" "all" --nonlinear $1