python3 toy_script.py --seeds_replicate 27 --n_observational 200 --n_trials 30 --n_anchor_points 35 --run_num 1
python3 toy_script.py --seeds_replicate 3 --n_observational 200 --n_trials 30 --n_anchor_points 35 --run_num 2
python3 toy_script.py --seeds_replicate 104 --n_observational 200 --n_trials 30 --n_anchor_points 35 --run_num 3
python3 toy_script.py --seeds_replicate 1234 --n_observational 200 --n_trials 30 --n_anchor_points 35 --run_num 4
python3 toy_script.py --seeds_replicate 321 --n_observational 200 --n_trials 30 --n_anchor_points 35 --run_num 5
