# Code Style and Conventions

## Import Conventions
```python
# Project-specific aliases (use exactly these)
import jax.numpy as jnp            # NEVER import as np
import numpy as onp                # "Original NumPy" - only for I/O
import jax.random as random        # For PRNG operations
import pyrsistent as pyr           # For immutable data structures

# Import order:
# 1. Standard library
# 2. Third-party (jax, pyrsistent, etc.)
# 3. AVICI imports
# 4. Local imports from src.causal_bayes_opt
```

## Code Style
- **Line length**: 100 characters (Black configuration)
- **Python version**: 3.9+ target
- **Type hints**: Required on all functions
- **Docstrings**: Google style preferred
- **Naming**: snake_case for functions/variables, PascalCase for classes

## JAX Compatibility Requirements
- **No string operations**: Use tensor operations for dynamic computations
- **No Python loops**: Use JAX vectorized operations or static loops
- **Compilation-ready**: All model components must be @jax.jit compatible
- **Data format consistency**: Maintain [N, d, 3] format throughout pipeline

## Architecture Standards
- **Functional programming**: Pure functions by default
- **Immutable data structures**: Use pyrsistent for SCMs/configs
- **Modular design**: Feature flags for optional capabilities
- **Backward compatibility**: Structure-only mode as fallback
- **Performance focus**: JAX compilation for training speedup
- **Clean interfaces**: Minimal breaking changes to existing APIs

## Domain-Specific Types
```python
from typing import FrozenSet, Dict, Any
import pyrsistent as pyr

# Use these type aliases
NodeId = str
InterventionValue = float
SCM = pyr.PMap
Sample = pyr.PMap
Mechanism = Callable[[Dict[NodeId, float], jax.Array], float]
```

## Data Structure Patterns
```python
# SCMs are immutable
scm = create_scm(
    variables=frozenset(['X', 'Y', 'Z']),
    edges=frozenset([('X', 'Y'), ('Z', 'Y')]),
    mechanisms=pyr.pmap({...}),
    target='Y'
)

# Samples are immutable
sample = create_sample(
    values=pyr.pmap({'X': 1.0, 'Y': 2.0}),
    interventions=pyr.pmap({'X': 1.0})  # X was intervened
)
```