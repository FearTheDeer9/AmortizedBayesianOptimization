# Design Patterns and Guidelines

## Core Design Principles

### Functional Programming First
- **Pure functions by default**: No side effects, no mutations
- **Single responsibility**: Each function does ONE thing well  
- **Composition over inheritance**: Build complex behavior from simple functions
- **Explicit over implicit**: Make intent clear, avoid magic

### Data Philosophy  
- **Immutable by default**: Use immutable data structures unless performance requires otherwise
- **Data > Functions > Macros**: Prefer data representations
- **Simple > Easy**: Prefer simple solutions even if they require more initial effort

### JAX-First Architecture
- **Compilation-ready**: All numerical code must be @jax.jit compatible
- **No string operations**: Use tensor operations for dynamic computations
- **Vectorized operations**: No Python loops in numerical code
- **Static shapes**: Prefer static shapes for compilation efficiency

## Specific Patterns

### Registry Pattern (Interventions)
```python
# Register intervention handlers
@register_intervention_handler("perfect")
def perfect_intervention_handler(scm, intervention_spec):
    # Implementation
```

### Factory Pattern (Model Creation)  
```python
# Create models through factory functions
model = create_unified_parent_set_model(config)
policy = create_acquisition_policy(config, example_state)
```

### Builder Pattern (Complex Configuration)
```python
# Build complex configurations step by step
config = (ConfigBuilder()
    .with_hidden_dim(128)
    .with_num_layers(4)
    .with_dropout(0.1)
    .build())
```

### Immutable State Pattern
```python
# All state objects are immutable
@dataclass(frozen=True)
class AcquisitionState:
    posterior: ParentSetPosterior
    buffer: ExperienceBuffer
    # No mutable fields
```

## Error Handling Patterns

### Defensive Programming
- **Fail fast**: Validate inputs immediately
- **Clear error messages**: Include context and suggestions
- **Graceful degradation**: Provide fallbacks where appropriate

### JAX Error Handling
```python
# Safe numerical operations
def safe_log(x):
    return jnp.log(jnp.maximum(x, 1e-12))

# Finite value checking
def validate_finite(x, name):
    if not jnp.all(jnp.isfinite(x)):
        raise ValueError(f"{name} contains non-finite values")
```

## Performance Patterns

### JAX Compilation
```python
# JIT compile numerical functions
@jax.jit
def compute_loss(params, batch):
    # Implementation
```

### Lazy Evaluation
```python
# Defer expensive computations
@property
def expensive_property(self):
    if not hasattr(self, '_cached_value'):
        self._cached_value = expensive_computation()
    return self._cached_value
```

### Vectorization
```python
# Process batches efficiently
def process_batch(data):
    return jax.vmap(process_single)(data)
```

## Testing Patterns

### Property-Based Testing
```python
from hypothesis import given, strategies as st

@given(st.floats(min_value=0, max_value=1))
def test_probability_properties(p):
    # Test properties that should always hold
```

### Fixture Factories
```python
@pytest.fixture
def sample_scm():
    return create_test_scm(variables=['X', 'Y'], target='Y')
```

## Deprecation Pattern
```python
import warnings

def deprecated_function():
    warnings.warn(
        "deprecated_function is deprecated, use new_function instead",
        DeprecationWarning,
        stacklevel=2
    )
    # Implementation or delegation to new function
```