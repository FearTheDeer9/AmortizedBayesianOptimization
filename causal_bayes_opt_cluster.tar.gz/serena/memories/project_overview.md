# Causal Bayesian Optimization Project Overview

## Purpose
This project implements the Amortized Causal Bayesian Optimization (ACBO) framework, combining AVICI's amortized inference with PARENT_SCALE's causal optimization approach for efficient causal discovery and intervention selection.

## Key Innovation
Uses amortized inference for both structure discovery and acquisition function modeling, enabling efficient causal Bayesian optimization.

## Architecture
The system follows a cyclic workflow:
```
Surrogate Model → Acquisition Model → SCM Environment → Surrogate Model
```

### Core Components
- **Parent Set Prediction Model**: Direct prediction of top-k parent sets for target variables
- **AVICI Integration**: Amortized inference using graph neural networks  
- **Target-Aware Architecture**: Uses [N, d, 3] input format (values, interventions, target indicators)
- **Acquisition Policy**: Neural network for intervention selection using GRPO
- **SCM Environment**: Immutable representations of structural causal models
- **Experience Buffer**: Trajectory storage with Sample dataclass

## Current Status
**Phase 1.3 Complete** - Stable Parent Set Prediction Model with numerical stability and bias-free architecture.

**Next Phase**: Phase 2 - Acquisition Model (RL with GRPO)

## Key Features
- Direct parent set prediction with O(k) scaling
- JAX-first design for performance
- Functional programming with immutable data structures
- Numerical stability (no NaN/Inf issues)
- Target-aware design
- Mechanism-aware enhancements