# Project Structure

## Main Directory Layout
```
causal_bayes_opt/
├── src/causal_bayes_opt/           # Core implementation
├── tests/                          # Tests and validation
├── examples/                       # Working examples and demos
├── docs/                          # Documentation
├── scripts/                       # Utility scripts
├── external/                      # External dependencies (PARENT_SCALE)
└── config files (pyproject.toml, CLAUDE.md, etc.)
```

## Core Source Structure (`src/causal_bayes_opt/`)
```
├── __init__.py                     # Main package exports
├── data_structures/                # Core immutable data structures
│   ├── scm.py                     # Structural Causal Model representation
│   ├── sample.py                  # Sample data structures
│   └── buffer.py                  # Experience buffer
├── mechanisms/                     # SCM mechanism implementations
│   ├── linear.py                  # Linear mechanisms
│   └── base.py                    # Base mechanism types
├── interventions/                  # Intervention system
│   ├── registry.py                # Intervention handler registry
│   └── handlers.py                # Built-in intervention handlers
├── environments/                   # SCM sampling and environment
│   └── sampling.py                # Intervention sampling
├── avici_integration/              # AVICI adaptation layer
│   ├── parent_set/                # Parent set prediction models
│   │   ├── unified/               # JAX-compatible unified models (preferred)
│   │   ├── model.py               # DEPRECATED parent set model
│   │   ├── inference.py           # Model inference
│   │   └── posterior.py           # Posterior handling
│   └── core/                      # Core conversion utilities
├── acquisition/                    # Acquisition function system
│   ├── state.py                   # Acquisition state representation
│   ├── policy.py                  # Neural policy networks
│   ├── rewards.py                 # Reward computation
│   ├── hybrid_rewards.py          # Mechanism-aware rewards (preferred)
│   └── grpo.py                    # Policy optimization
├── training/                       # Training pipelines
│   ├── surrogate_training.py      # Model training
│   ├── acquisition_training.py    # Policy training
│   └── master_trainer.py          # Orchestration
├── jax_native/                     # JAX-optimized operations
├── bridges/                        # Compatibility layers
├── algorithms/                     # Standalone algorithms
└── experiments/                    # Experimental utilities
```

## Key Files Reference
- `src/causal_bayes_opt/avici_integration/parent_set/unified/model.py` - JAX-compatible unified model (preferred)
- `src/causal_bayes_opt/acquisition/state.py` - Main acquisition state with mechanism-aware features
- `src/causal_bayes_opt/training/surrogate_training.py` - JAX-compiled training pipeline
- `examples/complete_workflow_demo.py` - Main demonstration of full pipeline

## Test Structure (`tests/`)
```
├── test_integration/              # Integration tests
├── test_acquisition/              # Acquisition function tests
├── test_avici_integration/        # AVICI integration tests
├── test_training/                 # Training pipeline tests
├── test_jax_native/              # JAX optimization tests
└── examples/                      # Test examples
```

## Configuration Files
- `pyproject.toml` - Python project configuration and dependencies
- `CLAUDE.md` - Project-specific coding guidelines and architecture notes
- `README.md` - Project overview and quick start guide