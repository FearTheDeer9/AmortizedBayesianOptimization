# Suggested Commands for Development

## Code Quality Commands
```bash
# Format code (required before commit)
black src/ tests/

# Lint and fix issues
ruff check src/ --fix
ruff check tests/ --fix

# Type checking (strict mode)
mypy src/ --strict

# Run all checks together
black src/ tests/ && ruff check src/ --fix && ruff check tests/ --fix && mypy src/ --strict
```

## Testing Commands
```bash
# Run all tests
pytest tests/

# Run tests with coverage
pytest tests/ --cov=causal_bayes_opt --cov-report=html

# Run specific test module
pytest tests/test_acquisition/ -v

# Run integration tests
pytest tests/test_integration/ -v

# Run with verbose output
pytest tests/ -v --strict-markers
```

## Example and Demo Commands
```bash
# Run main workflow demo
python examples/complete_workflow_demo.py

# Run PARENT_SCALE integration demo
python examples/parent_scale_demo.py

# Run mechanism-aware demo
python examples/mechanism_aware_demo.py

# Run JAX-native optimized demo
python examples/jax_native_demo.py

# Run performance comparison
python examples/performance_comparison.py

# Run comprehensive validation
python examples/run_comprehensive_validation.py
```

## Development Workflow Commands
```bash
# Create new branch
git checkout -b feature/your-feature-name

# Stage and commit changes
git add .
git commit -m "feat: your commit message"

# Push changes
git push origin feature/your-feature-name

# Check git status
git status

# View diff
git diff
```

## Package Management
```bash
# Install dependencies
pip install -r requirements.txt

# Install in development mode
pip install -e .

# Install with development dependencies
pip install -e .[dev]
```

## System-Specific Commands (macOS/Darwin)
```bash
# File operations
ls -la
find . -name "*.py" -type f
grep -r "pattern" src/

# Process management
ps aux | grep python
kill -9 <process_id>

# Directory navigation
cd /path/to/directory
pwd
```