# Task Completion Checklist

## Required Steps After Completing Any Task

### 1. Code Quality Checks (MANDATORY)
```bash
# Format code
black src/ tests/

# Lint and fix issues  
ruff check src/ --fix
ruff check tests/ --fix

# Type checking
mypy src/ --strict
```

### 2. Testing (MANDATORY)
```bash
# Run relevant tests
pytest tests/test_<relevant_module>/ -v

# Run integration tests if changes affect multiple modules
pytest tests/test_integration/ -v

# Ensure all tests pass before committing
pytest tests/ --tb=short
```

### 3. Validation for Specific Areas

#### For Model/Algorithm Changes:
```bash
# Run validation examples
python examples/complete_workflow_demo.py
python examples/mechanism_aware_demo.py

# Run performance validation
python examples/performance_comparison.py
```

#### For Training Pipeline Changes:
```bash
# Test training components
python examples/complete_acquisition_training_demo.py
pytest tests/test_training/ -v
```

#### For Data Structure Changes:
```bash
# Test core functionality
pytest tests/test_acquisition_state.py -v
pytest tests/test_trajectory_buffer.py -v
```

### 4. Documentation Updates
- Update docstrings for any modified functions/classes
- Update README.md if public API changes
- Update CLAUDE.md if architectural changes
- Add examples for new functionality

### 5. Git Workflow
```bash
# Check status
git status

# Stage changes
git add .

# Commit with descriptive message
git commit -m "feat/fix/refactor: brief description"

# Push to feature branch
git push origin feature/branch-name
```

### 6. Architecture Considerations
- Ensure JAX compatibility for numerical code
- Maintain immutable data structure patterns
- Follow functional programming principles
- Consider backward compatibility
- Check performance impact for large-scale changes

### 7. Integration Validation
- Test interaction with AVICI integration
- Verify SCM environment compatibility  
- Check acquisition policy integration
- Validate training pipeline end-to-end

## Failure Recovery
If any step fails:
1. Fix the specific issue
2. Re-run the failed step
3. Continue with remaining steps
4. Do not commit until all checks pass