# Technology Stack

## Core Technologies
- **Python**: 3.11+ (primary language)
- **JAX**: All numerical computation and model implementation
- **Haiku**: Neural network framework (from AVICI)
- **Optax**: Optimizers
- **PyRsistent**: Immutable data structures for SCMs/configs

## Key Libraries
- **numpy**: Only for I/O operations (imported as `onp`)
- **jax.numpy**: All numerical operations (imported as `jnp`) 
- **jax.random**: PRNG operations
- **typing-extensions**: Type hints
- **pydantic**: Configuration validation
- **tqdm**: Progress bars
- **hypothesis**: Property-based testing

## Scientific Computing
- **matplotlib**: Plotting and visualization
- **scipy**: Scientific functions
- **statsmodels**: Statistical modeling
- **networkx**: Graph operations
- **GPy**: Gaussian processes
- **emukit**: Emulation toolkit

## Development Tools
- **pytest**: Testing framework
- **black**: Code formatting
- **ruff**: Linting
- **mypy**: Type checking
- **pytest-cov**: Coverage reporting

## Forbidden Libraries
- **pandas**: Use JAX arrays + pyrsistent instead
- **sklearn**: Not JAX-compatible
- **tensorflow/pytorch**: Conflicts with JAX ecosystem

## Build System
- **setuptools**: Package building
- **pyproject.toml**: Modern Python project configuration