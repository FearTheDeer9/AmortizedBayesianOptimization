"""
Tests for JAX-Native Causal Bayesian Optimization System

This test suite validates the JAX-native implementation with comprehensive
unit tests, property-based testing, and JAX compilation verification.
"""